# Backlog de crear-agentes

Mejoras futuras (abiertas) y cambios aplicados o descartados, registrados con `mejorar-skills/scripts/backlog.py`.
Formato de entrada: `mejorar-skills/templates/backlog-entry.md`.

## BL-001 · abierta · 2026-09-17

- Origen: investigación de Antigravity.
- Propuesta: generar también reglas en `.agents/rules/` si se confirma que Antigravity no carga los `AGENTS.md` de subcarpetas.
- Condición para aplicarla: comprobarlo en una instalación real de Antigravity del usuario.

## BL-002 · aplicada · 2026-09-18

- Origen: El AGENTS.md de cada dominio debe listar sus skills en una tabla, no en viñetas
- Propuesta: dominio-squad.md usa tabla (tecnología o tarea, skill asignada, uso) y validate_agents_md.py acepta filas de tabla además de viñetas
- Condición para aplicarla: ninguna
