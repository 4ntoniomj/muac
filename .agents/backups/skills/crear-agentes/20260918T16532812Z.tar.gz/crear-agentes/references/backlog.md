# Backlog de crear-agentes

Mejoras futuras (abiertas) y cambios aplicados o descartados, registrados con `mejorar-skills/scripts/backlog.py`.
Formato de entrada: `mejorar-skills/templates/backlog-entry.md`.

## BL-001 · abierta · 2026-09-17

- Origen: investigación de Antigravity.
- Propuesta: generar también reglas en `.agents/rules/` si se confirma que Antigravity no carga los `AGENTS.md` de subcarpetas.
- Condición para aplicarla: comprobarlo en una instalación real de Antigravity del usuario.
